@echo off
echo Compiling DnaAnalyzer.java ...
javac DnaAnalyzer.java
if %errorlevel% neq 0 (
    echo.
    echo Compilation failed. Make sure Java 17+ is installed and on PATH.
    echo   java -version
    pause
    exit /b 1
)
echo.
echo Starting server ... open http://localhost:8080/ in your browser.
echo Press Ctrl+C to stop.
echo.
java DnaAnalyzer
pause
