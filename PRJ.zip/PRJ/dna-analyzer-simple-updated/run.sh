#!/usr/bin/env bash
set -e
echo "Compiling DnaAnalyzer.java ..."
javac DnaAnalyzer.java

echo ""
echo "Starting server ... open http://localhost:8080/ in your browser."
echo "Press Ctrl+C to stop."
echo ""
java DnaAnalyzer
