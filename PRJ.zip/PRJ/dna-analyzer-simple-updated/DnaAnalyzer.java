import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * =====================================================================
 *  DNA Sequence Analysis Tool - single-file, dependency-free edition
 * =====================================================================
 *
 * A DSA-III mini project: searches DNA motifs inside a genome sequence
 * using four hand-built string-matching algorithms - KMP, Z-Algorithm,
 * Rabin-Karp, and Aho-Corasick - and shows a side-by-side comparison.
 *
 * WHY THIS VERSION EXISTS:
 * The Maven/Spring Boot edition needs Maven installed correctly, an
 * internet connection to download dependencies, and a working IDE
 * toolchain. This edition needs only a plain JDK (17+) - nothing else.
 * It uses Java's built-in HTTP server (com.sun.net.httpserver, part of
 * every standard JDK) instead of Spring Boot, and plain HTML forms
 * instead of a JavaScript framework.
 *
 * HOW TO RUN (from a terminal, in the folder containing this file):
 *   javac DnaAnalyzer.java
 *   java DnaAnalyzer
 *   -> open http://localhost:8080/
 *
 * On Java 11+ you can even skip the separate compile step:
 *   java DnaAnalyzer.java
 *
 * No Maven. No Spring Boot. No database. No internet required to build.
 * =====================================================================
 */
public class DnaAnalyzer {

    private static final int PORT = 8080;

    /**
     * In-memory search history, shared for the lifetime of this running
     * server process. There is no database and nothing is written to disk -
     * this list simply lives in the JVM's heap and is lost when the server
     * stops. Capped at MAX_HISTORY entries (oldest dropped first) so a long
     * session doesn't grow memory usage unbounded.
     */
    private static final List<HistoryEntry> HISTORY = Collections.synchronizedList(new ArrayList<>());
    private static final int MAX_HISTORY = 20;
    private static final AtomicInteger HISTORY_ID_SEQ = new AtomicInteger(1);

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.createContext("/", new RootHandler());
        server.createContext("/search", new SearchHandler());
        server.createContext("/about", new AboutHandler());
        server.createContext("/history", new HistoryHandler());
        server.setExecutor(null); // default single-threaded executor - plenty for a local demo
        server.start();

        System.out.println("=================================================");
        System.out.println(" DNA Sequence Analysis Tool started successfully ");
        System.out.println(" Open:  http://localhost:" + PORT + "/            ");
        System.out.println(" Stop:  press Ctrl+C in this terminal             ");
        System.out.println("=================================================");
    }

    // =================================================================
    //  HTTP HANDLERS
    // =================================================================

    /** Serves the home/input page at GET "/". Anything else under "/" -> 404. */
    static class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            if (!"/".equals(path)) {
                sendHtml(exchange, 404, pageShell("Not Found", "<div class='card'><h2>404 - Page not found</h2>" +
                        "<p><a href='/'>Go back home</a></p></div>"));
                return;
            }
            if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendHtml(exchange, 405, "Method not allowed");
                return;
            }
            sendHtml(exchange, 200, renderResultPage("", "", null, null, ""));
        }
    }

    /** Handles POST "/search" - validates input, runs all 4 algorithms, renders results. */
    static class SearchHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendHtml(exchange, 405, "Method not allowed");
                return;
            }

            String contentType = exchange.getRequestHeaders().getFirst("Content-Type");
            String sequenceInput;
            String motifsInput;

            try {
                if (contentType != null && contentType.toLowerCase().startsWith("multipart/form-data")) {
                    String boundary = extractBoundary(contentType);
                    byte[] body = readAll(exchange.getRequestBody());
                    MultipartData multipart = parseMultipart(body, boundary);

                    byte[] fileBytes = multipart.fields.get("file");
                    String filename = multipart.filenames.get("file");
                    String sequenceField = multipart.fields.containsKey("sequence")
                            ? new String(multipart.fields.get("sequence"), StandardCharsets.UTF_8) : "";
                    motifsInput = multipart.fields.containsKey("motifs")
                            ? new String(multipart.fields.get("motifs"), StandardCharsets.UTF_8) : "";

                    if (fileBytes != null && fileBytes.length > 0 && filename != null && !filename.isBlank()) {
                        sequenceInput = new String(fileBytes, StandardCharsets.UTF_8);
                    } else {
                        sequenceInput = sequenceField;
                    }
                } else {
                    byte[] bodyBytes = readAll(exchange.getRequestBody());
                    Map<String, String> form = parseUrlEncoded(new String(bodyBytes, StandardCharsets.UTF_8));
                    sequenceInput = form.getOrDefault("sequence", "");
                    motifsInput = form.getOrDefault("motifs", "");
                }
            } catch (Exception e) {
                sendHtml(exchange, 400, renderResultPage("", "", "Failed to read the submitted form: " + e.getMessage(), null, ""));
                return;
            }

            String cleanedSequence = DnaUtil.clean(sequenceInput);
            List<String> rawMotifs = DnaUtil.parseMotifs(motifsInput);

            String error = null;
            SearchResult result = null;

            if (cleanedSequence.isEmpty()) {
                error = "Please provide a DNA sequence - paste it in the box, or upload a .txt/.fasta file.";
            } else if (!DnaUtil.isValidDna(cleanedSequence)) {
                error = "Sequence contains invalid character(s): " + DnaUtil.findInvalid(cleanedSequence)
                        + ". Only A, T, G, C are allowed.";
            } else if (rawMotifs.isEmpty()) {
                error = "Please enter at least one motif to search for.";
            } else {
                List<String> cleanedMotifs = new ArrayList<>();
                for (String m : rawMotifs) {
                    String cm = DnaUtil.clean(m);
                    if (cm.isEmpty()) continue;
                    if (!DnaUtil.isValidDna(cm)) {
                        error = "Motif '" + m + "' contains invalid character(s). Only A, T, G, C are allowed.";
                        break;
                    }
                    cleanedMotifs.add(cm);
                }
                if (error == null) {
                    if (cleanedMotifs.isEmpty()) {
                        error = "Please enter at least one valid motif.";
                    } else {
                        result = runSearch(cleanedSequence, cleanedMotifs);
                        saveToHistory(cleanedSequence, result);
                    }
                }
            }

            sendHtml(exchange, 200, renderResultPage(sequenceInput, motifsInput, error, result, cleanedSequence));
        }
    }

    /** Serves the "About" documentation page at GET "/about". */
    static class AboutHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            sendHtml(exchange, 200, renderAboutPage());
        }
    }

    /**
     * Handles everything under "/history":
     *   GET  /history            - list of past searches (most recent first)
     *   GET  /history/view       - full detail view of one past search (?id=N)
     *   GET  /history/download   - download one past search as .txt (?id=N)
     *   POST /history/clear      - wipe all history, then redirect back to /history
     */
    static class HistoryHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            String method = exchange.getRequestMethod();
            Map<String, String> query = parseUrlEncoded(exchange.getRequestURI().getRawQuery());

            if ("/history".equals(path) && "GET".equalsIgnoreCase(method)) {
                sendHtml(exchange, 200, renderHistoryListPage());
                return;
            }
            if ("/history/clear".equals(path) && "POST".equalsIgnoreCase(method)) {
                HISTORY.clear();
                sendRedirect(exchange, "/history");
                return;
            }
            if ("/history/view".equals(path) && "GET".equalsIgnoreCase(method)) {
                HistoryEntry entry = findHistoryEntry(query.get("id"));
                if (entry == null) {
                    sendHtml(exchange, 404, pageShell("Not Found",
                            "<div class='card'><h2>That history entry no longer exists.</h2>" +
                            "<p><a href='/history'>Back to history</a></p></div>"));
                    return;
                }
                sendHtml(exchange, 200, renderHistoryDetailPage(entry));
                return;
            }
            if ("/history/download".equals(path) && "GET".equalsIgnoreCase(method)) {
                HistoryEntry entry = findHistoryEntry(query.get("id"));
                if (entry == null) {
                    sendHtml(exchange, 404, "History entry not found.");
                    return;
                }
                sendTextFileDownload(exchange, "dna_search_" + entry.id + ".txt", buildDownloadText(entry.result));
                return;
            }

            sendHtml(exchange, 404, pageShell("Not Found", "<div class='card'><h2>404 - Page not found</h2>" +
                    "<p><a href='/'>Go back home</a></p></div>"));
        }
    }

    // =================================================================
    //  HTTP / PARSING UTILITIES
    // =================================================================

    private static void sendHtml(HttpExchange exchange, int statusCode, String html) throws IOException {
        byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStreamWrapper out = new OutputStreamWrapper(exchange)) {
            out.write(bytes);
        }
    }

    /** Tiny wrapper so we can use try-with-resources on the exchange's output stream. */
    private static class OutputStreamWrapper implements AutoCloseable {
        private final java.io.OutputStream os;
        OutputStreamWrapper(HttpExchange exchange) { this.os = exchange.getResponseBody(); }
        void write(byte[] bytes) throws IOException { os.write(bytes); }
        @Override public void close() throws IOException { os.close(); }
    }

    /** Sends a 303 "See Other" redirect - used after clearing history so a page refresh doesn't re-submit the POST. */
    private static void sendRedirect(HttpExchange exchange, String location) throws IOException {
        exchange.getResponseHeaders().set("Location", location);
        exchange.sendResponseHeaders(303, -1);
        exchange.close();
    }

    /** Streams a plain-text file back to the browser as a real download (server-side, for saved history entries). */
    private static void sendTextFileDownload(HttpExchange exchange, String filename, String content) throws IOException {
        byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/plain; charset=UTF-8");
        exchange.getResponseHeaders().set("Content-Disposition", "attachment; filename=\"" + filename + "\"");
        exchange.sendResponseHeaders(200, bytes.length);
        try (OutputStreamWrapper out = new OutputStreamWrapper(exchange)) {
            out.write(bytes);
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) {
            bos.write(buf, 0, n);
        }
        return bos.toByteArray();
    }

    private static Map<String, String> parseUrlEncoded(String body) {
        Map<String, String> map = new LinkedHashMap<>();
        if (body == null || body.isEmpty()) return map;
        for (String pair : body.split("&")) {
            int eq = pair.indexOf('=');
            if (eq < 0) continue;
            String key = urlDecode(pair.substring(0, eq));
            String value = urlDecode(pair.substring(eq + 1));
            map.put(key, value);
        }
        return map;
    }

    private static String urlDecode(String s) {
        try {
            return URLDecoder.decode(s, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return s;
        }
    }

    private static String extractBoundary(String contentType) {
        int idx = contentType.indexOf("boundary=");
        if (idx < 0) return "";
        String boundary = contentType.substring(idx + "boundary=".length());
        int semi = boundary.indexOf(';');
        if (semi >= 0) boundary = boundary.substring(0, semi);
        boundary = boundary.trim();
        if (boundary.startsWith("\"") && boundary.endsWith("\"")) {
            boundary = boundary.substring(1, boundary.length() - 1);
        }
        return boundary;
    }

    private static class MultipartData {
        Map<String, byte[]> fields = new LinkedHashMap<>();
        Map<String, String> filenames = new HashMap<>();
    }

    /** Minimal multipart/form-data parser - handles simple text + single-file forms. */
    private static MultipartData parseMultipart(byte[] body, String boundary) {
        MultipartData result = new MultipartData();
        if (boundary.isEmpty()) return result;

        byte[] boundaryBytes = ("--" + boundary).getBytes(StandardCharsets.UTF_8);
        byte[] headerBodySep = "\r\n\r\n".getBytes(StandardCharsets.UTF_8);

        int pos = indexOf(body, boundaryBytes, 0);
        while (pos != -1) {
            int partStart = pos + boundaryBytes.length;
            if (partStart + 1 < body.length && body[partStart] == '-' && body[partStart + 1] == '-') {
                break; // reached the final boundary marker "--boundary--"
            }
            partStart = skipLeadingCrlf(body, partStart);

            int nextBoundary = indexOf(body, boundaryBytes, partStart);
            if (nextBoundary == -1) break;

            int sepIdx = indexOf(body, headerBodySep, partStart);
            if (sepIdx == -1 || sepIdx > nextBoundary) {
                pos = nextBoundary;
                continue;
            }

            String headers = new String(body, partStart, sepIdx - partStart, StandardCharsets.UTF_8);
            int contentStart = sepIdx + headerBodySep.length;
            int contentEnd = Math.max(contentStart, nextBoundary - 2); // strip trailing CRLF before next boundary

            byte[] content = Arrays.copyOfRange(body, contentStart, contentEnd);

            String name = extractHeaderParam(headers, "name");
            String filename = extractHeaderParam(headers, "filename");
            if (name != null) {
                result.fields.put(name, content);
                if (filename != null && !filename.isBlank()) {
                    result.filenames.put(name, filename);
                }
            }
            pos = nextBoundary;
        }
        return result;
    }

    private static int skipLeadingCrlf(byte[] data, int from) {
        int i = from;
        if (i + 1 < data.length && data[i] == '\r' && data[i + 1] == '\n') {
            i += 2;
        }
        return i;
    }

    private static int indexOf(byte[] data, byte[] pattern, int from) {
        outer:
        for (int i = from; i <= data.length - pattern.length; i++) {
            for (int j = 0; j < pattern.length; j++) {
                if (data[i + j] != pattern[j]) continue outer;
            }
            return i;
        }
        return -1;
    }

    private static final Pattern HEADER_PARAM_PATTERN_TEMPLATE = Pattern.compile("");

    private static String extractHeaderParam(String headers, String param) {
        Matcher m = Pattern.compile(param + "=\"([^\"]*)\"").matcher(headers);
        return m.find() ? m.group(1) : null;
    }

    private static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    private static String escapeJs(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "");
    }

    // =================================================================
    //  DNA VALIDATION
    // =================================================================

    static class DnaUtil {

        private static final Pattern VALID_DNA = Pattern.compile("^[ATGC]+$");

        /** Strips FASTA header lines (starting with '>'), removes whitespace, upper-cases. */
        static String clean(String raw) {
            if (raw == null) return "";
            StringBuilder sb = new StringBuilder();
            for (String line : raw.split("\\r?\\n")) {
                String trimmed = line.trim();
                if (trimmed.startsWith(">")) continue;
                sb.append(trimmed);
            }
            return sb.toString().replaceAll("\\s+", "").toUpperCase();
        }

        static boolean isValidDna(String s) {
            return s != null && !s.isEmpty() && VALID_DNA.matcher(s).matches();
        }

        static String findInvalid(String s) {
            StringBuilder invalid = new StringBuilder();
            for (char c : s.toCharArray()) {
                if ("ATGC".indexOf(c) == -1 && invalid.indexOf(String.valueOf(c)) == -1) {
                    invalid.append(c);
                }
            }
            return invalid.toString();
        }

        /** Splits a motif textarea's content on newlines and/or commas into a clean list. */
        static List<String> parseMotifs(String raw) {
            List<String> motifs = new ArrayList<>();
            if (raw == null) return motifs;
            for (String m : raw.split("[\\n,]+")) {
                String trimmed = m.trim();
                if (!trimmed.isEmpty()) motifs.add(trimmed);
            }
            return motifs;
        }
    }

    // =================================================================
    //  ALGORITHM 1: Knuth-Morris-Pratt (KMP)
    //  Time: O(n + m)   Space: O(m)
    // =================================================================
    static class KMP {
        static List<Integer> search(String text, String pattern) {
            List<Integer> matches = new ArrayList<>();
            int n = text.length(), m = pattern.length();
            if (m == 0 || n < m) return matches;

            int[] lps = new int[m];
            int len = 0, i = 1;
            while (i < m) {
                if (pattern.charAt(i) == pattern.charAt(len)) {
                    lps[i++] = ++len;
                } else if (len > 0) {
                    len = lps[len - 1];
                } else {
                    lps[i++] = 0;
                }
            }

            i = 0;
            int j = 0;
            while (i < n) {
                if (text.charAt(i) == pattern.charAt(j)) {
                    i++; j++;
                    if (j == m) {
                        matches.add(i - j);
                        j = lps[j - 1];
                    }
                } else if (j > 0) {
                    j = lps[j - 1];
                } else {
                    i++;
                }
            }
            return matches;
        }
    }

    // =================================================================
    //  ALGORITHM 2: Z-Algorithm
    //  Time: O(n + m)   Space: O(n + m)
    // =================================================================
    static class ZAlgo {
        private static final char SEP = '\u0001';

        static List<Integer> search(String text, String pattern) {
            List<Integer> matches = new ArrayList<>();
            int n = text.length(), m = pattern.length();
            if (m == 0 || n < m) return matches;

            String s = pattern + SEP + text;
            int[] z = buildZArray(s);
            int offset = m + 1;
            for (int i = offset; i < s.length(); i++) {
                if (z[i] == m) matches.add(i - offset);
            }
            return matches;
        }

        private static int[] buildZArray(String s) {
            int n = s.length();
            int[] z = new int[n];
            int left = 0, right = 0;
            for (int i = 1; i < n; i++) {
                if (i < right) {
                    z[i] = Math.min(right - i, z[i - left]);
                }
                while (i + z[i] < n && s.charAt(z[i]) == s.charAt(i + z[i])) {
                    z[i]++;
                }
                if (i + z[i] > right) {
                    left = i;
                    right = i + z[i];
                }
            }
            return z;
        }
    }

    // =================================================================
    //  ALGORITHM 3: Rabin-Karp (polynomial rolling hash)
    //  Time: O(n + m) average, O(n*m) worst   Space: O(1)
    // =================================================================
    static class RabinKarp {
        private static final int BASE = 256;
        private static final long MOD = 1_000_000_007L;

        static List<Integer> search(String text, String pattern) {
            List<Integer> matches = new ArrayList<>();
            int n = text.length(), m = pattern.length();
            if (m == 0 || n < m) return matches;

            long patternHash = 0, windowHash = 0, highOrder = 1;
            for (int i = 0; i < m - 1; i++) highOrder = (highOrder * BASE) % MOD;

            for (int i = 0; i < m; i++) {
                patternHash = (BASE * patternHash + pattern.charAt(i)) % MOD;
                windowHash = (BASE * windowHash + text.charAt(i)) % MOD;
            }

            for (int i = 0; i <= n - m; i++) {
                if (patternHash == windowHash && text.regionMatches(i, pattern, 0, m)) {
                    matches.add(i);
                }
                if (i < n - m) {
                    windowHash = (BASE * (windowHash - text.charAt(i) * highOrder) + text.charAt(i + m)) % MOD;
                    if (windowHash < 0) windowHash += MOD;
                }
            }
            return matches;
        }
    }

    // =================================================================
    //  ALGORITHM 4: Aho-Corasick (multi-pattern matching)
    //  Time: O(n + sum(pattern lengths) + matches)   Space: O(sum(pattern lengths))
    // =================================================================
    static class AhoCorasick {
        private static class Node {
            Map<Character, Node> children = new HashMap<>();
            Node fail;
            List<String> outputs = new ArrayList<>();
        }

        static Map<String, List<Integer>> searchMultiple(String text, List<String> patterns) {
            Map<String, List<Integer>> results = new LinkedHashMap<>();
            for (String p : patterns) results.put(p, new ArrayList<>());

            Node root = new Node();
            for (String p : patterns) {
                if (p.isEmpty()) continue;
                Node node = root;
                for (char c : p.toCharArray()) {
                    node = node.children.computeIfAbsent(c, k -> new Node());
                }
                node.outputs.add(p);
            }

            Deque<Node> queue = new ArrayDeque<>();
            root.fail = root;
            for (Node child : root.children.values()) {
                child.fail = root;
                queue.add(child);
            }
            while (!queue.isEmpty()) {
                Node current = queue.poll();
                for (Map.Entry<Character, Node> entry : current.children.entrySet()) {
                    char c = entry.getKey();
                    Node child = entry.getValue();
                    Node fail = current.fail;
                    while (fail != root && !fail.children.containsKey(c)) {
                        fail = fail.fail;
                    }
                    if (fail.children.containsKey(c) && fail.children.get(c) != child) {
                        child.fail = fail.children.get(c);
                    } else {
                        child.fail = root;
                    }
                    child.outputs.addAll(child.fail.outputs);
                    queue.add(child);
                }
            }

            Node current = root;
            for (int i = 0; i < text.length(); i++) {
                char c = text.charAt(i);
                while (current != root && !current.children.containsKey(c)) {
                    current = current.fail;
                }
                current = current.children.getOrDefault(c, root);
                for (String matched : current.outputs) {
                    results.get(matched).add(i - matched.length() + 1);
                }
            }
            return results;
        }
    }

    // =================================================================
    //  SEARCH ORCHESTRATION
    // =================================================================

    static class Match {
        final String motif;
        final int start; // 0-based
        final int end;   // 0-based, inclusive
        Match(String motif, int start, int end) { this.motif = motif; this.start = start; this.end = end; }
    }

    static class AlgoStat {
        final String name;
        final String timeComplexity;
        final String spaceComplexity;
        long nanos;
        final List<Match> matches = new ArrayList<>();
        AlgoStat(String name, String timeComplexity, String spaceComplexity) {
            this.name = name; this.timeComplexity = timeComplexity; this.spaceComplexity = spaceComplexity;
        }
        double millis() { return nanos / 1_000_000.0; }
    }

    static class SearchResult {
        int sequenceLength;
        List<String> motifs;
        List<AlgoStat> stats = new ArrayList<>();
        String bestAlgorithm;
    }

    /**
     * One saved entry in the in-memory search history: a timestamp, the
     * exact cleaned sequence that was searched (needed to re-render the
     * highlighted view or regenerate a download later), and the full
     * result of that search.
     */
    static class HistoryEntry {
        final int id;
        final String timestamp;
        final String sequence;
        final SearchResult result;

        HistoryEntry(int id, String timestamp, String sequence, SearchResult result) {
            this.id = id;
            this.timestamp = timestamp;
            this.sequence = sequence;
            this.result = result;
        }
    }

    /** Appends a completed search to the in-memory history, evicting the oldest entry past MAX_HISTORY. */
    private static void saveToHistory(String sequence, SearchResult result) {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        int id = HISTORY_ID_SEQ.getAndIncrement();
        synchronized (HISTORY) {
            HISTORY.add(0, new HistoryEntry(id, timestamp, sequence, result)); // newest first
            while (HISTORY.size() > MAX_HISTORY) {
                HISTORY.remove(HISTORY.size() - 1);
            }
        }
    }

    private static HistoryEntry findHistoryEntry(String idParam) {
        if (idParam == null) return null;
        int id;
        try {
            id = Integer.parseInt(idParam);
        } catch (NumberFormatException e) {
            return null;
        }
        synchronized (HISTORY) {
            for (HistoryEntry e : HISTORY) {
                if (e.id == id) return e;
            }
        }
        return null;
    }

    static SearchResult runSearch(String sequence, List<String> motifs) {
        SearchResult result = new SearchResult();
        result.sequenceLength = sequence.length();
        result.motifs = motifs;

        AlgoStat kmp = new AlgoStat("Knuth-Morris-Pratt (KMP)", "O(n + m)", "O(m)");
        long start = System.nanoTime();
        for (String motif : motifs) {
            for (int pos : KMP.search(sequence, motif)) kmp.matches.add(new Match(motif, pos, pos + motif.length() - 1));
        }
        kmp.nanos = System.nanoTime() - start;
        result.stats.add(kmp);

        AlgoStat z = new AlgoStat("Z-Algorithm", "O(n + m)", "O(n + m)");
        start = System.nanoTime();
        for (String motif : motifs) {
            for (int pos : ZAlgo.search(sequence, motif)) z.matches.add(new Match(motif, pos, pos + motif.length() - 1));
        }
        z.nanos = System.nanoTime() - start;
        result.stats.add(z);

        AlgoStat rk = new AlgoStat("Rabin-Karp", "O(n + m) avg, O(n\u00b7m) worst", "O(1)");
        start = System.nanoTime();
        for (String motif : motifs) {
            for (int pos : RabinKarp.search(sequence, motif)) rk.matches.add(new Match(motif, pos, pos + motif.length() - 1));
        }
        rk.nanos = System.nanoTime() - start;
        result.stats.add(rk);

        AlgoStat ac = new AlgoStat("Aho-Corasick", "O(n + m + z)", "O(m)");
        start = System.nanoTime();
        Map<String, List<Integer>> multi = AhoCorasick.searchMultiple(sequence, motifs);
        ac.nanos = System.nanoTime() - start;
        for (Map.Entry<String, List<Integer>> e : multi.entrySet()) {
            for (int pos : e.getValue()) ac.matches.add(new Match(e.getKey(), pos, pos + e.getKey().length() - 1));
        }
        result.stats.add(ac);

        AlgoStat fastest = result.stats.get(0);
        for (AlgoStat s : result.stats) if (s.nanos < fastest.nanos) fastest = s;
        result.bestAlgorithm = fastest.name;

        return result;
    }

    // =================================================================
    //  HTML TEMPLATES  (plain HTML forms - no JS framework, no CDN)
    // =================================================================

    private static String pageShell(String title, String bodyContent) {
        return """
                <!DOCTYPE html>
                <html lang="en">
                <head>
                <meta charset="UTF-8"/>
                <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
                <title>%s | DNA Sequence Analyzer</title>
                <style>%s</style>
                </head>
                <body>
                <script>
                  (function() {
                    var saved = localStorage.getItem('dna-theme');
                    if (saved === 'dark') document.documentElement.setAttribute('data-theme', 'dark');
                  })();
                </script>
                <nav class="navbar">
                  <div class="nav-inner">
                    <a class="brand" href="/">DNA Sequence Analyzer</a>
                    <div class="nav-links">
                      <a href="/">Home</a>
                      <a href="/history">History</a>
                      <a href="/about">About</a>
                      <button id="themeBtn" onclick="toggleTheme()">Toggle Dark/Light</button>
                    </div>
                  </div>
                </nav>
                <main class="container">
                %s
                </main>
                <footer class="footer">
                  <p>DNA Sequence Analysis Tool &middot; DSA-III Mini Project &middot; No database, no cloud services, runs entirely on localhost.</p>
                </footer>
                <script>
                  function toggleTheme() {
                    var html = document.documentElement;
                    if (html.getAttribute('data-theme') === 'dark') {
                      html.removeAttribute('data-theme');
                      localStorage.setItem('dna-theme', 'light');
                    } else {
                      html.setAttribute('data-theme', 'dark');
                      localStorage.setItem('dna-theme', 'dark');
                    }
                  }
                  function downloadResults() {
                    var text = window.__resultsText || '';
                    var blob = new Blob([text], { type: 'text/plain' });
                    var url = URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.href = url;
                    a.download = 'dna_search_results.txt';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                  }
                </script>
                </body>
                </html>
                """.formatted(escapeHtml(title), CSS, bodyContent);
    }

    private static String renderResultPage(String sequenceRaw, String motifsRaw, String error, SearchResult result, String cleanedSequence) {
        StringBuilder body = new StringBuilder();

        body.append("<h1>DNA Sequence Analysis Tool</h1>");
        body.append("<p class='subtitle'>Search DNA motifs using KMP, Z-Algorithm, Rabin-Karp and Aho-Corasick.</p>");

        body.append("""
                <div class="card">
                <form method="post" action="/search" enctype="multipart/form-data">
                  <label class="form-label">DNA Sequence (paste it, or choose a file below)</label>
                  <textarea name="sequence" class="dna-textarea" rows="8" placeholder="e.g. ATGCGTACGTTAGC...">%s</textarea>

                  <label class="form-label" style="margin-top:1rem;">Or upload a .txt / .fasta file</label>
                  <input type="file" name="file" accept=".txt,.fasta,.fa" class="file-input"/>

                  <label class="form-label" style="margin-top:1rem;">Motifs to search (one per line, or comma separated)</label>
                  <textarea name="motifs" class="dna-textarea" rows="4" placeholder="ATG&#10;TATA&#10;GCC">%s</textarea>

                  <button type="submit" class="btn-primary" style="margin-top:1rem;">Run Search (All 4 Algorithms)</button>
                </form>
                </div>
                """.formatted(escapeHtml(sequenceRaw), escapeHtml(motifsRaw)));

        if (error != null) {
            body.append("<div class='alert-error'>").append(escapeHtml(error)).append("</div>");
        }

        if (result != null) {
            body.append(renderStatsCards(result));
            body.append(renderHighlightedSequence(cleanedSequence, result));
            body.append(renderAlgoTable(result));
            body.append(renderMatchTable(result));

            body.append("<button type='button' class='btn-secondary' onclick='downloadResults()'>Download Results (TXT)</button>");
            body.append(" <a href='/history' class='btn-secondary' style='display:inline-block;text-decoration:none;'>View Search History</a>");
            body.append("<script>window.__resultsText = '").append(escapeJs(buildDownloadText(result))).append("';</script>");
        }

        return pageShell("Home", body.toString());
    }

    private static String renderStatsCards(SearchResult r) {
        int maxOccurrences = 0;
        for (AlgoStat s : r.stats) maxOccurrences = Math.max(maxOccurrences, s.matches.size());

        return """
                <h2>Results Dashboard</h2>
                <div class="stats-grid">
                  <div class="stat-card"><div class="stat-value">%d</div><div class="stat-label">Sequence Length</div></div>
                  <div class="stat-card"><div class="stat-value">%d</div><div class="stat-label">Motifs Searched</div></div>
                  <div class="stat-card"><div class="stat-value">%d</div><div class="stat-label">Total Occurrences</div></div>
                  <div class="stat-card"><div class="stat-value">%s</div><div class="stat-label">Best Algorithm</div></div>
                </div>
                """.formatted(r.sequenceLength, r.motifs.size(), maxOccurrences, escapeHtml(r.bestAlgorithm));
    }

    private static String renderHighlightedSequence(String sequence, SearchResult r) {
        AlgoStat best = r.stats.get(0);
        for (AlgoStat s : r.stats) if (s.matches.size() > best.matches.size()) best = s;

        List<Match> ranges = new ArrayList<>(best.matches);
        ranges.sort(Comparator.comparingInt(m -> m.start));

        StringBuilder html = new StringBuilder();
        int cursor = 0;
        for (Match m : ranges) {
            if (m.start < cursor) continue;
            html.append(escapeHtml(sequence.substring(cursor, m.start)));
            html.append("<mark>").append(escapeHtml(sequence.substring(m.start, m.end + 1))).append("</mark>");
            cursor = m.end + 1;
        }
        html.append(escapeHtml(sequence.substring(cursor)));

        return "<h3>Highlighted Sequence</h3><div class='sequence-view'>" + html + "</div>";
    }

    private static String renderAlgoTable(SearchResult r) {
        long maxNanos = 1;
        for (AlgoStat s : r.stats) maxNanos = Math.max(maxNanos, s.nanos);

        StringBuilder rows = new StringBuilder();
        for (AlgoStat s : r.stats) {
            boolean isBest = s.name.equals(r.bestAlgorithm);
            int barPct = (int) Math.max(2, (s.nanos * 100L) / maxNanos);
            rows.append("<tr><td>").append(escapeHtml(s.name));
            if (isBest) rows.append(" <span class='badge'>Fastest</span>");
            rows.append("</td><td>").append(s.matches.size())
                    .append("</td><td>").append(String.format(Locale.US, "%.4f", s.millis()))
                    .append("<div class='bar-track'><div class='bar-fill' style='width:").append(barPct).append("%'></div></div>")
                    .append("</td><td>").append(escapeHtml(s.timeComplexity))
                    .append("</td><td>").append(escapeHtml(s.spaceComplexity))
                    .append("</td></tr>");
        }

        return """
                <h3>Per-Algorithm Results</h3>
                <table class="data-table">
                <thead><tr><th>Algorithm</th><th>Occurrences</th><th>Execution Time (ms)</th><th>Time Complexity</th><th>Space Complexity</th></tr></thead>
                <tbody>%s</tbody>
                </table>
                """.formatted(rows);
    }

    private static String renderMatchTable(SearchResult r) {
        StringBuilder rows = new StringBuilder();
        for (AlgoStat s : r.stats) {
            for (Match m : s.matches) {
                rows.append("<tr><td>").append(escapeHtml(s.name))
                        .append("</td><td>").append(escapeHtml(m.motif))
                        .append("</td><td>").append(m.start + 1)
                        .append("</td><td>").append(m.end + 1)
                        .append("</td></tr>");
            }
        }
        if (rows.isEmpty()) {
            rows.append("<tr><td colspan='4'>No matches found.</td></tr>");
        }
        return """
                <h3>Match Positions (1-based)</h3>
                <table class="data-table small">
                <thead><tr><th>Algorithm</th><th>Motif</th><th>Start</th><th>End</th></tr></thead>
                <tbody>%s</tbody>
                </table>
                """.formatted(rows);
    }

    private static String buildDownloadText(SearchResult r) {
        StringBuilder sb = new StringBuilder();
        sb.append("DNA Sequence Analysis - Search Results\n");
        sb.append("========================================\n");
        sb.append("Sequence length: ").append(r.sequenceLength).append("\n");
        sb.append("Motifs searched: ").append(String.join(", ", r.motifs)).append("\n");
        sb.append("Best algorithm: ").append(r.bestAlgorithm).append("\n\n");
        for (AlgoStat s : r.stats) {
            sb.append("--- ").append(s.name).append(" ---\n");
            sb.append("Occurrences: ").append(s.matches.size()).append("\n");
            sb.append("Execution time: ").append(String.format(Locale.US, "%.4f", s.millis())).append(" ms\n");
            for (Match m : s.matches) {
                sb.append("  motif=").append(m.motif).append(" start=").append(m.start + 1).append(" end=").append(m.end + 1).append("\n");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    /** Renders the "/history" page: a table of every saved search, most recent first. */
    private static String renderHistoryListPage() {
        StringBuilder body = new StringBuilder();
        body.append("<h1>Search History</h1>");
        body.append("<p class='subtitle'>Every search run during this server session (kept in memory only - " +
                "nothing is written to disk, and it resets when the server restarts).</p>");

        List<HistoryEntry> snapshot;
        synchronized (HISTORY) {
            snapshot = new ArrayList<>(HISTORY);
        }

        if (snapshot.isEmpty()) {
            body.append("<div class='card'><p>No searches yet. Run one from the <a href='/'>Home page</a> " +
                    "and it will show up here.</p></div>");
            return pageShell("Search History", body.toString());
        }

        body.append("""
                <form method="post" action="/history/clear" onsubmit="return confirm('Clear all search history? This cannot be undone.');" style="margin-bottom:1.2rem;">
                  <button type="submit" class="btn-secondary">Clear All History</button>
                </form>
                """);

        StringBuilder rows = new StringBuilder();
        for (HistoryEntry e : snapshot) {
            int maxOccurrences = 0;
            for (AlgoStat s : e.result.stats) maxOccurrences = Math.max(maxOccurrences, s.matches.size());
            rows.append("<tr>")
                    .append("<td>#").append(e.id).append("</td>")
                    .append("<td>").append(escapeHtml(e.timestamp)).append("</td>")
                    .append("<td>").append(e.result.sequenceLength).append("</td>")
                    .append("<td>").append(escapeHtml(String.join(", ", e.result.motifs))).append("</td>")
                    .append("<td>").append(maxOccurrences).append("</td>")
                    .append("<td>").append(escapeHtml(e.result.bestAlgorithm)).append("</td>")
                    .append("<td>")
                    .append("<a class='btn-secondary' style='margin:0 4px 0 0;padding:0.3rem 0.7rem;display:inline-block;text-decoration:none;' href='/history/view?id=").append(e.id).append("'>View</a>")
                    .append("<a class='btn-secondary' style='margin:0;padding:0.3rem 0.7rem;display:inline-block;text-decoration:none;' href='/history/download?id=").append(e.id).append("'>Download</a>")
                    .append("</td>")
                    .append("</tr>");
        }

        body.append("""
                <table class="data-table small">
                <thead><tr><th>ID</th><th>When</th><th>Seq. Length</th><th>Motifs</th><th>Occurrences</th><th>Best Algorithm</th><th>Actions</th></tr></thead>
                <tbody>%s</tbody>
                </table>
                """.formatted(rows));

        return pageShell("Search History", body.toString());
    }

    /** Renders the full detail view (stats, highlighted sequence, tables) for one saved history entry. */
    private static String renderHistoryDetailPage(HistoryEntry entry) {
        StringBuilder body = new StringBuilder();
        body.append("<h1>Search #").append(entry.id).append("</h1>");
        body.append("<p class='subtitle'>Run at ").append(escapeHtml(entry.timestamp)).append(" &middot; ")
                .append("<a href='/history'>&larr; Back to History</a></p>");

        body.append(renderStatsCards(entry.result));
        body.append(renderHighlightedSequence(entry.sequence, entry.result));
        body.append(renderAlgoTable(entry.result));
        body.append(renderMatchTable(entry.result));

        body.append("<a class='btn-secondary' style='display:inline-block;text-decoration:none;' href='/history/download?id=")
                .append(entry.id).append("'>Download Results (TXT)</a>");

        return pageShell("Search #" + entry.id, body.toString());
    }

    private static String renderAboutPage() {
        String body = """
                <h1>About This Project</h1>

                <div class="card">
                  <h3>Abstract</h3>
                  <p>The DNA Sequence Analysis Tool is a web-based application that locates biological motifs
                  within genome sequences using four string-matching algorithms: Knuth-Morris-Pratt (KMP), the
                  Z-Algorithm, Rabin-Karp, and Aho-Corasick. It lets a user paste a sequence or upload a genome
                  file, search for one or many motifs simultaneously, and compare execution time, match counts,
                  and documented complexity side by side.</p>
                </div>

                <div class="card">
                  <h3>Problem Statement</h3>
                  <p>Naive scanning of genome sequences for known motifs is computationally expensive at scale
                  (O(n&middot;m) per search). This tool applies sub-quadratic / linear-time string-matching
                  algorithms to solve pattern-search, multi-pattern-search, and algorithm-selection problems on
                  DNA data.</p>
                </div>

                <div class="card">
                  <h3>Objectives</h3>
                  <ul>
                    <li>Accurately locate gene/motif patterns inside DNA sequences.</li>
                    <li>Support simultaneous search of multiple motifs via Aho-Corasick.</li>
                    <li>Measure and compare real execution time and documented complexity.</li>
                    <li>Validate input strictly to the DNA alphabet {A, T, G, C}.</li>
                    <li>Run entirely offline, with no database and no external services.</li>
                  </ul>
                </div>

                <div class="card">
                  <h3>Architecture</h3>
                  <pre class="architecture">
                Browser (plain HTML forms, no JS framework)
                        |
                        |  standard HTML POST (multipart or url-encoded)
                        v
                +-------------------------------+
                |  DnaAnalyzer (single file)     |
                |  - HttpServer request routing  |
                |  - DnaUtil (validation)        |
                |  - KMP / ZAlgo / RabinKarp /    |
                |    AhoCorasick (algorithms)     |
                |  - HTML template rendering      |
                +-------------------------------+

                No database. No external/cloud APIs. No Maven/Spring Boot.
                Pure JDK (com.sun.net.httpserver), one .java file.
                  </pre>
                </div>

                <div class="card">
                  <h3>Time &amp; Space Complexity</h3>
                  <table class="data-table">
                    <thead><tr><th>Algorithm</th><th>Time</th><th>Space</th></tr></thead>
                    <tbody>
                      <tr><td>KMP</td><td>O(n + m)</td><td>O(m)</td></tr>
                      <tr><td>Z-Algorithm</td><td>O(n + m)</td><td>O(n + m)</td></tr>
                      <tr><td>Rabin-Karp</td><td>O(n + m) avg / O(n&middot;m) worst</td><td>O(1)</td></tr>
                      <tr><td>Aho-Corasick</td><td>O(n + m + z)</td><td>O(m)</td></tr>
                    </tbody>
                  </table>
                </div>

                <div class="card">
                  <h3>Advantages</h3>
                  <ul>
                    <li>Linear-time matching, scales to large genomes.</li>
                    <li>Multi-motif search in a single pass.</li>
                    <li>Zero external dependencies - runs anywhere a JDK runs.</li>
                  </ul>
                </div>

                <div class="card">
                  <h3>Limitations</h3>
                  <ul>
                    <li>Exact matching only (no fuzzy/approximate search).</li>
                    <li>In-memory processing; very large files are bound by available heap.</li>
                    <li>No search history persistence between requests (stateless by design).</li>
                  </ul>
                </div>

                <div class="card">
                  <h3>Future Scope</h3>
                  <ul>
                    <li>Add fuzzy motif matching via Edit Distance / Smith-Waterman.</li>
                    <li>Add suffix array + LCP based document similarity across genomes.</li>
                    <li>Add reverse-complement motif search.</li>
                  </ul>
                </div>
                """;
        return pageShell("About", body);
    }

    // -----------------------------------------------------------------
    //  CSS - embedded so the whole app is a single self-contained file.
    //  Theme: a bioinformatics-inspired teal/violet palette with a subtle
    //  double-helix backdrop, built entirely from CSS gradients (no
    //  external images, fonts, or CDN links - stays 100% offline).
    // -----------------------------------------------------------------
    private static final String CSS = """
            :root {
              --bg: #eef3f6; --bg-accent1: #e4f3ef; --bg-accent2: #eee7f7;
              --text: #16202b; --card-bg: #ffffff; --card-bg-soft: #fbfdff; --border: #dbe4ea;
              --accent: #0e9c8f; --accent-2: #7c5cff; --accent-soft: rgba(14,156,143,0.12);
              --muted: #5b6b78; --highlight: #ffe58f; --nav-bg: rgba(255,255,255,0.85);
              --shadow: 0 4px 18px rgba(20,40,60,0.07);
            }
            [data-theme="dark"] {
              --bg: #0b1220; --bg-accent1: #0e1a22; --bg-accent2: #150f28;
              --text: #e6edf3; --card-bg: #131c2b; --card-bg-soft: #101827; --border: #223047;
              --accent: #2be0c8; --accent-2: #a78bfa; --accent-soft: rgba(43,224,200,0.14);
              --muted: #93a2b3; --highlight: #4a3b00; --nav-bg: rgba(11,18,32,0.85);
              --shadow: 0 4px 22px rgba(0,0,0,0.35);
            }
            * { box-sizing: border-box; }
            html { scroll-behavior: smooth; }
            body {
              margin:0; font-family: 'Segoe UI', -apple-system, Roboto, Arial, sans-serif;
              color: var(--text);
              background-color: var(--bg);
              background-image:
                radial-gradient(circle at 8% 12%, var(--bg-accent1) 0%, transparent 42%),
                radial-gradient(circle at 92% 82%, var(--bg-accent2) 0%, transparent 45%),
                repeating-linear-gradient(115deg, rgba(14,156,143,0.05) 0px, rgba(14,156,143,0.05) 2px,
                                           transparent 2px, transparent 46px),
                repeating-linear-gradient(65deg, rgba(124,92,255,0.05) 0px, rgba(124,92,255,0.05) 2px,
                                           transparent 2px, transparent 46px);
              background-attachment: fixed;
              min-height: 100vh;
            }
            .navbar {
              background: var(--nav-bg); backdrop-filter: blur(8px);
              border-bottom: 1px solid var(--border); padding: 0.85rem 1rem;
              position: sticky; top: 0; z-index: 10;
            }
            .nav-inner { max-width: 980px; margin: 0 auto; display:flex; justify-content: space-between; align-items:center; }
            .brand {
              font-weight: 800; text-decoration:none; font-size:1.15rem; letter-spacing:0.2px;
              background: linear-gradient(90deg, var(--accent), var(--accent-2));
              -webkit-background-clip: text; background-clip: text; color: transparent;
            }
            .brand::before { content: "\\1F9EC  "; -webkit-text-fill-color: initial; }
            .nav-links a { color: var(--text); text-decoration:none; margin-right:1.1rem; font-weight:500; }
            .nav-links a:hover { color: var(--accent); }
            .nav-links button {
              background: var(--card-bg); border:1px solid var(--border); color: var(--text);
              padding: 0.4rem 0.8rem; border-radius: 20px; cursor:pointer; font-size:0.85rem;
              transition: border-color 0.15s ease, transform 0.1s ease;
            }
            .nav-links button:hover { border-color: var(--accent); transform: translateY(-1px); }
            .container { max-width: 980px; margin: 0 auto; padding: 2rem 1rem 3rem; }
            h1 {
              font-size: 2.1rem; margin-bottom:0.3rem;
              background: linear-gradient(90deg, var(--accent), var(--accent-2));
              -webkit-background-clip: text; background-clip: text; color: transparent;
              display:inline-block;
            }
            h2, h3 { color: var(--text); }
            .subtitle { color: var(--muted); margin-top:0; margin-bottom:1.5rem; font-size:1.02rem; }
            .card {
              background: var(--card-bg); border:1px solid var(--border); border-radius: 14px;
              padding: 1.4rem; margin-bottom: 1.4rem; box-shadow: var(--shadow);
              transition: box-shadow 0.15s ease, transform 0.15s ease;
            }
            .card:hover { box-shadow: 0 8px 26px rgba(20,40,60,0.1); }
            [data-theme="dark"] .card:hover { box-shadow: 0 8px 28px rgba(0,0,0,0.45); }
            .form-label { display:block; font-weight:600; margin-bottom:0.45rem; color: var(--text); }
            .dna-textarea {
              width:100%; font-family: 'Courier New', monospace; font-size:0.95rem;
              padding:0.7rem; border-radius:8px; border:1px solid var(--border);
              background: var(--card-bg-soft); color: var(--text); resize: vertical;
              transition: border-color 0.15s ease;
            }
            .dna-textarea:focus { outline:none; border-color: var(--accent); }
            .file-input { display:block; color: var(--text); }
            .btn-primary {
              background: linear-gradient(90deg, var(--accent), var(--accent-2));
              color:#fff; border:none; padding:0.75rem 1.4rem; border-radius:10px;
              font-size:1rem; font-weight:600; cursor:pointer; box-shadow: 0 4px 14px rgba(14,156,143,0.3);
              transition: transform 0.12s ease, box-shadow 0.12s ease;
            }
            .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 6px 18px rgba(14,156,143,0.4); }
            .btn-secondary {
              background: transparent; color: var(--accent); border:1.5px solid var(--accent);
              padding:0.6rem 1.2rem; border-radius:10px; cursor:pointer; margin-top:1rem; font-weight:600;
              transition: background 0.12s ease;
            }
            .btn-secondary:hover { background: var(--accent-soft); }
            .alert-error {
              background: #ffe4e4; color:#7a1212; border:1px solid #f5b5b5;
              padding:0.9rem 1.1rem; border-radius:10px; margin-bottom:1.4rem; font-weight:500;
            }
            [data-theme="dark"] .alert-error { background:#2a1414; color:#ff9d9d; border-color:#4a2222; }
            .stats-grid { display:grid; grid-template-columns: repeat(auto-fit, minmax(160px,1fr)); gap:1rem; margin-bottom:1.6rem; }
            .stat-card {
              background: var(--card-bg); border:1px solid var(--border); border-radius:14px;
              padding:1.1rem; text-align:center; box-shadow: var(--shadow);
            }
            .stat-value {
              font-size:1.7rem; font-weight:800;
              background: linear-gradient(90deg, var(--accent), var(--accent-2));
              -webkit-background-clip: text; background-clip: text; color: transparent;
            }
            .stat-label { color: var(--muted); font-size:0.78rem; text-transform:uppercase; letter-spacing:0.5px; margin-top:0.2rem; }
            .sequence-view {
              font-family:'Courier New', monospace; background: var(--card-bg-soft); border:1px solid var(--border);
              border-radius:10px; padding:1.1rem; max-height:320px; overflow-y:auto; word-break:break-all;
              line-height:1.9; margin-bottom:1.6rem; font-size:0.92rem;
            }
            .sequence-view mark {
              background: var(--highlight); border-radius:4px; padding:1px 2px;
              box-shadow: 0 0 0 1px rgba(0,0,0,0.05);
            }
            .data-table { width:100%; border-collapse:collapse; margin-bottom:1.6rem; border-radius:10px; overflow:hidden; }
            .data-table th {
              background: var(--accent-soft); color: var(--text); text-transform:uppercase;
              font-size:0.72rem; letter-spacing:0.4px; padding:0.6rem 0.7rem; text-align:left;
            }
            .data-table td { border-top:1px solid var(--border); padding:0.55rem 0.7rem; text-align:left; background: var(--card-bg); }
            .data-table.small { font-size:0.85rem; }
            .badge {
              background: linear-gradient(90deg, var(--accent), var(--accent-2));
              color:#fff; font-size:0.68rem; padding:0.18rem 0.5rem; border-radius:20px; font-weight:600;
            }
            .bar-track { background: var(--accent-soft); border-radius:6px; height:7px; margin-top:5px; overflow:hidden; }
            .bar-fill { background: linear-gradient(90deg, var(--accent), var(--accent-2)); height:7px; border-radius:6px; }
            .architecture {
              background: var(--card-bg-soft); border:1px solid var(--border); border-radius:10px;
              padding:1rem; font-size:0.78rem; overflow-x:auto;
            }
            .co-table td:first-child, .co-table th:first-child { white-space: nowrap; font-weight:700; color: var(--accent); }
            .footer { text-align:center; color: var(--muted); padding:1.8rem; border-top:1px solid var(--border); font-size:0.85rem; }
            """;
}
