# DNA Sequence Analysis Tool — Simple Edition

A **single-file, zero-dependency** version of the DSA-III mini project.
No Maven, no Spring Boot, no internet connection needed to build. Just a
JDK (17 or newer) and two commands.

Implements four string-matching algorithms from scratch:
**KMP**, **Z-Algorithm**, **Rabin-Karp**, and **Aho-Corasick** (multi-motif).

---

## Requirements

Only a JDK, version 17 or later. Check with:

```bash
java -version
javac -version
```

If either command fails, install a JDK:
- Windows: download from [Adoptium](https://adoptium.net/) (Temurin) or `winget install EclipseAdoptium.Temurin.17.JDK`
- Mac: `brew install openjdk@17`
- Linux: `sudo apt install openjdk-17-jdk`

No Maven. No Spring Boot. No other tools required.

---

## Run it — 2 commands

Open a terminal (VS Code's integrated terminal, Command Prompt, PowerShell,
or a regular terminal — any of them works) in the folder containing
`DnaAnalyzer.java`, then:

```bash
javac DnaAnalyzer.java
java DnaAnalyzer
```

Then open **http://localhost:8080/** in your browser.

### Even simpler — one click

- **Windows:** double-click `run.bat`
- **Mac/Linux:** run `./run.sh` in a terminal

### Even simpler still (Java 11+)

Skip the separate compile step entirely — Java can compile-and-run a
single source file in one command:

```bash
java DnaAnalyzer.java
```

To stop the server, press `Ctrl+C` in the terminal.

---

## How to use it

1. Open http://localhost:8080/
2. Paste a DNA sequence into the text box, **or** choose a `.txt`/`.fasta`
   file to upload (try `sample-data/sample_genome.fasta`).
3. Enter one or more motifs to search for (one per line, or comma-separated).
4. Click **"Run Search (All 4 Algorithms)"**.
5. See the highlighted sequence, per-algorithm timing/complexity table,
   full match-position table, and download the results as a `.txt` file.
6. Visit **/about** for the project write-up (abstract, objectives,
   architecture, complexity table, advantages/limitations/future scope).

## Search History

Every completed search is automatically saved to an in-memory history list
(the last 20 searches are kept - older ones roll off automatically).

- Click **"History"** in the navbar (or **"View Search History"** after
  running a search) to see every past search: timestamp, sequence length,
  motifs searched, occurrence count, and the fastest algorithm.
- Click **"View"** on any entry to reopen its full results page, with the
  sequence re-highlighted exactly as it appeared originally.
- Click **"Download"** on any entry to save that specific search's results
  as a `.txt` file - this works even for old entries, not just your most
  recent search.
- Click **"Clear All History"** to wipe every saved search (you'll be
  asked to confirm first).

**Important:** history is kept only in the server's memory for as long as
it keeps running - there is still no database and nothing is written to
disk. Stopping the server (`Ctrl+C`) or restarting your computer clears
it completely, by design (matching the project's "no database, fully
offline" requirement).

---

## Why this version instead of the Spring Boot one

The Maven + Spring Boot edition is architecturally "more textbook MVC" but
depends on a correctly configured Maven install and internet access to
download dependencies — that's what was causing trouble. This edition:

- Uses only `com.sun.net.httpserver.HttpServer`, part of every standard JDK.
- Is one `.java` file — no build tool, no dependency resolution, nothing
  that can be "not found on PATH".
- Renders plain HTML forms (no JavaScript framework, no CDN links) so it
  also works with **zero internet access** at runtime.
- Still implements the same four algorithms, with the same correctness —
  verified against each other (all four agree on match positions for the
  same input).

## Project structure

```
dna-analyzer-simple/
├── DnaAnalyzer.java        <- the entire application
├── run.bat                 <- Windows one-click launcher
├── run.sh                  <- Mac/Linux one-click launcher
├── README.md
└── sample-data/
    └── sample_genome.fasta <- try this on the File Upload option
```

## Time & Space Complexity

| Algorithm | Time | Space |
|---|---|---|
| KMP | O(n + m) | O(m) |
| Z-Algorithm | O(n + m) | O(n + m) |
| Rabin-Karp | O(n + m) avg, O(n·m) worst | O(1) |
| Aho-Corasick | O(n + m + z) | O(m) |

(`n` = sequence length, `m` = motif length(s), `z` = number of matches)

## Troubleshooting

- **`javac` not recognized** — your JDK isn't on PATH, or you only have a
  JRE (no compiler) installed. Reinstall from the links above and make
  sure to check "Add to PATH" during setup.
- **Port 8080 already in use** — close whatever else is using it, or open
  `DnaAnalyzer.java`, change `private static final int PORT = 8080;` near
  the top to another number (e.g. `8090`), and recompile.
- **Nothing happens when you open the browser** — check the terminal for
  the "DNA Sequence Analysis Tool started successfully" message; if it's
  missing, scroll up in the terminal for the actual error and share it.
